﻿Configuration FirstDC
{
    param( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullorEmpty()]
        [String]$domainName,

        [Parameter(Mandatory)]
        [String]$ExchangeServerIP,

        [Parameter(Mandatory)]
        [String]$AdfsServerIP,

        [Parameter(Mandatory)]
        [String]$DnsDomainName
    ) 

    Import-DscResource -ModuleName xActiveDirectory,xAdcsDeployment,xDnsServer

    [System.Management.Automation.PSCredential]$domainCred = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
        }

        xADDomain FirstDS
        {
            DomainName = $domainName
            DomainAdministratorCredential = $domainCred
            SafemodeAdministratorPassword = $domainCred
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADCS-Cert-Authority
        {
               Ensure = 'Present'
               Name = 'ADCS-Cert-Authority'
               DependsOn = '[xADDomain]FirstDS'
               Credential = $DomainCred
        }

        xADCSCertificationAuthority ADCS
        {
            Ensure = 'Present'
            Credential = $DomainCred
            CAType = 'EnterpriseRootCA'
            DependsOn = '[WindowsFeature]ADCS-Cert-Authority'              
        }

        WindowsFeature ADCS-Web-Enrollment
        {
            Ensure = 'Present'
            Name = 'ADCS-Web-Enrollment'
            DependsOn = '[WindowsFeature]ADCS-Cert-Authority'
            Credential = $DomainCred            
        }

        xADCSWebEnrollment CertSrv
        {
            Ensure = 'Present'
            Name = 'CertSrv'
            Credential = $DomainCred
            DependsOn = '[WindowsFeature]ADCS-Web-Enrollment','[xADCSCertificationAuthority]ADCS'
        }

        WindowsFeature RSAT-ADCS
        {
            Ensure = 'Present'
            Name = 'RSAT-ADCS'
        }

        WindowsFeature RSAT-AD-Tools
        {
            Ensure = 'Present'
            Name = 'RSAT-AD-Tools'
            IncludeAllSubFeature = $true
        }

        xDnsRecord Mail
        {
            Name   = 'mail'
            Zone   = $DnsDomainName
            Target = $ExchangeServerIP
            Type   = 'ARecord'
            Ensure = 'Present'
        }

        xDnsRecord Autodiscover
        {
            Name   = 'autodiscover'
            Zone   = $DnsDomainName
            Target = $ExchangeServerIP
            Type   = 'ARecord'
            Ensure = 'Present'
        }

        xDnsRecord sts
        {
            Name   = 'sts'
            Zone   = $DnsDomainName
            Target = $AdfsServerIP
            Type   = 'ARecord'
            Ensure = 'Present'
        }

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true 
        }
    }
}