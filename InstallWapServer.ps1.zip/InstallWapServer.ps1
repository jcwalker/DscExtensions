﻿Configuration InstallWapServer
{

    param
    (
        [pscredential]$Admincreds,
        [string]$DomainName,
        [string]$FedServiceName,
        [String]$CertThumbprint,
        [string]$CertPath,
        [string]$CertUri
    )

    Import-DscResource -ModuleName xWebApplicationProxy,xCertificate,xPSDesiredStateConfiguration,xComputerManagement

    $domainCred = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {    
        xComputer JoinDomain
        {  
            Name = $env:COMPUTERNAME
            DomainName = $domainName
            Credential = $DomainCred
        }

        WindowsFeature Web-Application-Proxy
        {
            Name = 'Web-Application-Proxy'
            Ensure = 'Present'
            IncludeAllSubFeature = $true
            DependsOn = '[xComputer]JoinDomain' 
        }
        xRemoteFile DLCert
        {
            DestinationPath = $CertPath
            Uri             = $CertUri 
            DependsOn = '[WindowsFeature]Web-Application-Proxy'          
        }

        xPfxImport ImportCert
        {
            Location   = 'LocalMachine'
            Path       = $CertPath
            Store      = 'My'
            Thumbprint = $CertThumbprint            
            Ensure     = 'Present'
            Credential = $domainCred
            DependsOn  = '[xRemoteFile]DLCert'           
        }
        
        xInstallWebApplicationProxy InstallWap
        {
            FederationServiceName = $FedServiceName
            CertificateThumbprint = $CertThumbprint
            FederationServiceTrustCredential = $domainCred
            DependsOn = '[xPfxImport]ImportCert'
        }

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
    }

}