﻿Configuration InstallAdfsServer
{
    Param
    (
        [pscredential]$Admincreds,
        [string]$FedServiceDisplayName,
        [string]$FedServiceName,
        [string]$DomainName,
        [String]$CertPath,
        [String]$CertThumbprint,
        [String]$CertUri,
        [string]$AdfsSrvActName
    )

    Import-DscResource -ModuleName xAdfs,xComputerManagement,xCertificate,xPSDesiredStateConfiguration,xActiveDirectory

    $domainCred = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $adfsCred   = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdfsSrvActName)", $Admincreds.Password)
    
    node localhost
    {
        xComputer JoinDomain
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $domainCred
        }
        WindowsFeature InstallAd-PowerShell
        {
            Name = 'RSAT-AD-PowerShell'
            Ensure = 'Present'
        }

        xADUser AdfsSrv
        {
            DomainName = $DomainName
            UserName = $AdfsSrvActName
            Password = $adfsCred 
            Ensure = 'Present'
            Enabled = $true
            DomainAdministratorCredential = $domainCred
            DependsOn = '[xComputer]JoinDomain','[WindowsFeature]InstallAD-PowerShell'

        }

        xRemoteFile DLCert
        {
            DestinationPath = $CertPath
            Uri             = $CertUri           
        }

        xPfxImport ImportCert
        {
            Location   = 'LocalMachine'
            Path       = $CertPath
            Store      = 'My'
            Thumbprint = $CertThumbprint            
            Ensure     = 'Present'
            Credential = $domainCred
            DependsOn  = '[xRemoteFile]DLCert'           
        }

        WindowsFeature InstallAdfs
        {
            Name   = 'ADFS-Federation'
            Ensure = 'Present'            
        }        

        xAdfsFarm FristAdfsServer
        {
            FederationServiceName = $FedServiceName
            FederationServiceDisplayName = $FedServiceDisplayName
            CertificateThumbprint = $CertThumbprint 
            DecryptionCertificateThumbprint = $CertThumbprint 
            SigningCertificateThumbprint = $CertThumbprint             
            ServiceAccountCredential = $adfsCred
            Credential = $domainCred
            OverwriteConfiguration = $true
            DependsOn = '[WindowsFeature]InstallAdfs'
        }
        
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        } 
    }
}

