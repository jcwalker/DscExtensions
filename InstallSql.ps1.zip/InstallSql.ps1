﻿configuration InstallSql
{
    param
    (
        [PSCredential]$AdminCreds,
        [String]$DomainName,
        [String]$SqlAdmin,
        [String]$SoftwareSourcePath = 'C:\InstallFiles'
    )

    Import-DscResource -ModuleName xStorage,xComputerManagement,xSQLServer

    [System.Management.Automation.PSCredential]$domainCred = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $SqlAdmin = $domainCred.UserName
    $SqlIsoPath = Join-Path -Path $SoftwareSourcePath -ChildPATH 'SQLFULL_ENU.iso'
    $SqlSourcePath = Join-Path $SoftwareSourcePath -ChildPath "Sql"

    node localhost
    {
        xComputer JoinDomain
        {  
            Name = $env:COMPUTERNAME
            DomainName = $domainName
            Credential = $DomainCred
        }
        
        Script DlSql
        {
            SetScript = {
                $DlPath = $using:SoftwareSourcePath

                If(!(Test-Path -Path $DlPath))
                {
                    New-Item -Path $DlPath -ItemType Directory
                }
                Write-Verbose "Downloading SQL ISO"
                $webclient = New-Object System.Net.WebClient
                $url = "https://download.microsoft.com/download/4/C/7/4C7D40B9-BCF8-4F8A-9E76-06E9B92FE5AE/ENU/SQLFULL_ENU.iso"
                $webclient.DownloadFile($url,$using:SqlIsoPath)   
            
            }

            TestScript = {
                            
                Test-Path -Path $using:SqlIsoPath
            }

            GetScript = {
                
                @{SqlIsoFilePath = (Get-Item -Path $using:SqlIsoPath)}
            }
            DependsOn = '[xComputer]JoinDomain'
        }

        xMountImage MountSqlIso
        {             
            Name = 'SQL Disk'
            ImagePath = $SqlIsoPath
            DriveLetter = 's:'
            Ensure = 'Present'
            DependsOn = '[Script]DlSql'
            
        }

        File CopySqlBits
        {
            DependsOn = '[xMountImage]MountSqlIso'
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            Recurse = $true # Ensure presence of subdirectories, too
            SourcePath = "S:\"
            DestinationPath = $SqlSourcePath

        }

        WindowsFeature "NET"
        {
            Ensure = "Present"
            Name = "NET-Framework-Core"
            DependsOn = '[xComputer]JoinDomain'            
        }

        xSQLServerSetup InstallSql
        {            
            SourcePath = $SoftwareSourcePath
            SourceFolder = 'Sql'
            SetupCredential = $DomainCred
            InstanceName = "MSSQLSERVER"
            Features = "SQLENGINE,SSMS"
            SQLSysAdminAccounts = $SqlAdmin
            DependsOn = '[WindowsFeature]NET'
        }

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
    }

}
