﻿configuration FirstExchangeServerARM

{
    param
    (
        [PSCredential]$AdminCreds,
        [PSCredential]$CertCreds,
        [String]$DomainName,
        [String]$SoftwareSourcePath,
        [String]$ServerName,
        [String]$CertPath,
        [String]$CertThumbprint,
        [String]$CertUri,
        [String]$ExternalUrl,
        [String]$InternalUrl,
        [String]$AutoDDnsName,
        [String]$ExchangeOrgName
        

    )

    Import-DscResource -ModuleName xComputerManagement,xPSDesiredStateConfiguration,xPendingReboot,xSystemVirtualMemory,xPowerShellExecutionPolicy,xExchange,xCertificate

    [System.Management.Automation.PSCredential]$domainCred = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $RequiredFeatures = @('RSAT-DNS-Server','Windows-Identity-Foundation','Web-WMI','Web-Windows-Auth','Web-Static-Content','Web-Stat-Compression','Web-Server','Web-Request-Monitor','Web-Net-Ext45','Web-Mgmt-Service','Web-Mgmt-Console','Web-Metabase','Web-Lgcy-Mgmt-Console','Web-ISAPI-Filter','Web-ISAPI-Ext','Web-Http-Tracing','Web-Http-Redirect','Web-Http-Logging','Web-Http-Errors','Web-Dyn-Compression','Web-Dir-Browsing','Web-Digest-Auth','Web-Client-Auth','Web-Basic-Auth','Web-Asp-Net45','WAS-Process-Model','RSAT-Clustering-PowerShell','RSAT-Clustering-Mgmt','RSAT-Clustering-CmdInterface','RSAT-Clustering','RPC-over-HTTP-proxy','NET-Framework-45-Features','Desktop-Experience','AS-HTTP-Activation','RSAT-ADDS')


    node localhost
    {
        xComputer JoinDomain
        {
            Name = $ServerName
            DomainName = $domainName
            Credential = $DomainCred
        }

        Script DlExchcu12
        {
            SetScript = {
                $DlPath = $using:SoftwareSourcePath

                If(!(Test-Path -Path $DlPath))
                {
                    New-Item -Path $DlPath -ItemType Directory
                }
                Write-Verbose "Downloading Exchange 2013 RU12"
                $webclient = New-Object System.Net.WebClient
                $url = "https://download.microsoft.com/download/2/C/1/2C151059-9B2A-466B-8220-5AE8B829489B/Exchange2013-x64-cu12.exe"
                $file = "$DlPath\Exchange2013-x64-cu12.exe"
                $webclient.DownloadFile($url,$file)
            
            
            }

            TestScript = {

                $DlPath = $using:SoftwareSourcePath
                Test-Path -Path "$DlPath\Exchange2013-x64-cu12.exe"
            }

            GetScript = {
                $DlPath = $using:SoftwareSourcePath
                @{ExchCUFilePath = (Get-Item -Path "$DlPath\Exchange2013-x64-cu12.exe")}
            }
            DependsOn = '[xComputer]JoinDomain'
        }

        Script DlUCMA
        {
            SetScript = {
                $DlPath = $using:SoftwareSourcePath

                If(!(Test-Path -Path $DlPath))
                {
                    New-Item -Path $DlPath -ItemType Directory
                }
                Write-Verbose "Downloading UCMA Runtime Setup"
                $webclient = New-Object System.Net.WebClient
                $url = "http://download.microsoft.com/download/2/C/4/2C47A5C1-A1F3-4843-B9FE-84C0032C61EC/UcmaRuntimeSetup.exe"
                $file = "$DlPath\UcmaRuntimeSetup.exe"
                $webclient.DownloadFile($url,$file)
            }

            TestScript = {

                $DlPath = $using:SoftwareSourcePath
                Test-Path -Path "$DlPath\UcmaRuntimeSetup.exe"
            }

            GetScript = {
                $DlPath = $using:SoftwareSourcePath
                @{ExchCUFilePath = (Get-Item -Path "$DlPath\UcmaRuntimeSetup.exe")}
            }
        }

        Script DotNet452
        {
            SetScript = {
                $DlPath = $using:SoftwareSourcePath

                If(!(Test-Path -Path $DlPath))
                {
                    New-Item -Path $DlPath -ItemType Directory
                }
                Write-Verbose "Downloading Dot NET 4.5.2"
                $webclient = New-Object System.Net.WebClient
                $url = "https://download.microsoft.com/download/E/2/1/E21644B5-2DF2-47C2-91BD-63C560427900/NDP452-KB2901907-x86-x64-AllOS-ENU.exe"
                $file = "$DlPath\NDP452-KB2901907-x86-x64-AllOS-ENU.exe"
                $webclient.DownloadFile($url,$file)
            }

            TestScript = {

                $DlPath = $using:SoftwareSourcePath
                Test-Path -Path "$DlPath\NDP452-KB2901907-x86-x64-AllOS-ENU.exe"
            }

            GetScript = {
                $DlPath = $using:SoftwareSourcePath
                @{ExchCUFilePath = (Get-Item -Path "$DlPath\NDP452-KB2901907-x86-x64-AllOS-ENU.exe")}
            }
        }

        Script ExtractExchangeBits
        {
            SetScript = {
                $Destination = "$($using:SoftwareSourcePath)\Exch2013"
                $ExchangeCab = (Get-ChildItem "$($using:SoftwareSourcePath)\Exchange2013*")
                Write-Verbose "Exchange Cab: $($ExchangeCab.FullName)"
                $CabProcess = Start-Process $ExchangeCab.FullName -ArgumentList "/extract:$destination /passive" -PassThru

                Start-Sleep -Seconds 1
                While($CabProcess.Handles)
                {
                    Write-Verbose "Waiting for Exchange install files to be extracted."
                    Sleep -Seconds 20

                    $CabProcess.Refresh()            
                }
            }

            TestScript = {
                $Destination = "$($using:SoftwareSourcePath)\Exch2013"
                Write-Verbose "Destination: $Destination"
                Try
                {
                    $ExchBitsExist = Get-ChildItem $Destination -ErrorAction Stop
                }
                Catch
                {
                    Write-Warning $_
                }
                If($ExchBitsExist.count -ge 70)
                {
                    Return $true
                }
                Else
                {
                    Write-Verbose "Exchange install files not found in in $Destination"
                    Return $false
                }
            }

            GetScript = { return @{ExchangBitsFolderSItemCount = $ExchBitsExist.Length} }
            DependsOn = '[Script]DlExchcu12'
        }
        
        #Starting point for CPB required resources
        xSystemVirtualMemory PageFile
        {
            InitialSize = '32768'
            MaximumSize = '32768'
            ConfigureOption = 'CustomSize'
            DriveLetter = 'C:'
        }

        Service NetTCPPortSharing
        {
            Name = 'NetTCPPortSharing'
            StartupType = 'Automatic'
            State = 'Running'
        }

        xPowerShellExecutionPolicy Unrestricted
        {
            ExecutionPolicy  = 'Unrestricted'
        }

        xPackage DotNet452
        {
            Name = 'NDP452'
            Path =  "$($SoftwareSourcePath)\NDP452-KB2901907-x86-x64-AllOS-ENU.exe"
            Arguments = '/q /norestart'
            InstalledCheckRegHive = 'LocalMachine'
            InstalledCheckRegKey = 'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
            InstalledCheckRegValueName = 'Release'
            InstalledCheckRegValueData = '379893'
            Ensure = 'Present'
            ProductId = ""
            DependsOn = '[Script]DotNet452'
        }

        xPendingReboot AfterDotNet
        {
            Name = 'RebootAfterDotNetInstall'
            DependsOn = '[xPackage]DotNet452'
        }

        
        #Install required Windows features
        Foreach($feature in $RequiredFeatures)
        {
            WindowsFeature $feature
            {
                Ensure = 'Present'
                Name = $feature
                DependsOn = '[xPendingReboot]AfterDotNet'
            }
        }
        
        Package UcmaRuntime
        {
            Name = 'UcmaRuntimeSetup'
            ProductId = 'ED98ABF5-B6BF-47ED-92AB-1CDCAB964447'
            Arguments = ' /passive'
            Path = "$($SoftwareSourcePath)\UcmaRuntimeSetup.exe"
            Ensure = 'Present'
            DependsOn = "[WindowsFeature]$feature"
        }

        xPendingReboot BeforeExchangeInstall
        {
            Name = 'RebootBeforeExchangeInstall'
            DependsOn = '[Package]UcmaRuntime'
        }
                
        xExchInstall InstallExchange
        {
            Path       = "$($SoftwareSourcePath)\Exch2013\Setup.exe"
            Arguments  = "/mode:Install /role:Mailbox,ClientAccess /Iacceptexchangeserverlicenseterms /MdbName:DB1 /DbFilePath:C:\ExchangeDatabases\DB1\DB1.edb /LogFolderPath:C:\ExchangeDatabases\DB1\Logs /OrganizationName:$($ExchangeOrgName)"
            Credential = $DomainCred
            DependsOn  = '[xPendingReboot]BeforeExchangeInstall'
        }

        xPendingReboot AfterExchangeInstall
        {
            Name      = "AfterExchangeInstall"

            DependsOn = '[xExchInstall]InstallExchange'
        }

        xExchWebServicesVirtualDirectory EWS
        {
            Identity    = "$($ServerName)\EWS (Default Web Site)" 
            ExternalUrl = "https://$($ExternalURL)/EWS/Exchange.asmx"
            InternalUrl = "https://$($InternalURL)/EWS/Exchange.asmx"
            AllowServiceRestart = $true
            Credential  = $DomainCred
            DependsOn = '[xPendingReboot]AfterExchangeInstall'
        }

        xExchOwaVirtualDirectory OWA
        {
            Identity   = "$($ServerName)\owa (Default Web Site)"
            ExternalUrl = "https://$($ExternalURL)/owa"
            InternalUrl = "https://$($InternalURL)/owa"
            AllowServiceRestart = $true
            Credential  = $DomainCred
            DependsOn = '[xExchWebServicesVirtualDirectory]EWS'
        }

        xExchEcpVirtualDirectory ECP
        {
            Identity   = "$($ServerName)\ecp (Default Web Site)"
            ExternalUrl = "https://$($ExternalURL)/ecp"
            InternalUrl = "https://$($InternalURL)/ecp"
            AllowServiceRestart = $true
            Credential          = $DomainCred
            DependsOn = '[xExchOwaVirtualDirectory]OWA'
        }

        xExchOutlookAnywhere OAVdir
        {
            Identity                           = "$($ServerName)\Rpc (Default Web Site)"
            Credential                         = $DomainCred
            ExternalClientAuthenticationMethod = 'Ntlm'
            ExternalClientsRequireSSL          = $true
            ExternalHostName                   = $ExternalURL
            IISAuthenticationMethods           = 'Ntlm'
            InternalClientAuthenticationMethod = 'Ntlm'
            InternalClientsRequireSSL          = $true
            InternalHostName                   = $InternalURL
            AllowServiceRestart                = $true
            DependsOn = '[xExchEcpVirtualDirectory]ECP'
        }

        xExchMapiVirtualDirectory MAPIVdir
        {
            Identity                 = "$($ServerName)\mapi (Default Web Site)"
            Credential               = $DomainCred
            ExternalUrl              = "https://$($ExternalURL)/mapi"
            IISAuthenticationMethods = 'NTLM','Negotiate'
            InternalUrl              = "https://$($InternalURL)/mapi" 
            AllowServiceRestart      = $true
            Dependson = '[xExchOutlookAnywhere]OAVdir'
        }

        xExchOabVirtualDirectory OABVdir
        {
            Identity            = "$($ServerName)\OAB (Default Web Site)"
            Credential          = $DomainCred
            ExternalUrl         = "https://$($ExternalURL)/oab"
            InternalUrl         = "https://$($InternalURL)/oab"           
            AllowServiceRestart = $true
            DependsOn = '[xExchMapiVirtualDirectory]MAPIVdir'
        }

        xExchClientAccessServer CAS
        {
            Identity                       = $ServerName
            Credential                     = $DomainCred
            AutoDiscoverServiceInternalUri = "https://$($AutoDDnsName)/autodiscover/autodiscover.xml"
            DependsOn = '[xExchOabVirtualDirectory]OABVdir'
            
        }
        
        xRemoteFile DLCert
        {
            DestinationPath = $CertPath
            Uri             = $CertUri
        }

        xPfxImport ExchCert
        {
            Thumbprint = $CertThumbprint
            Path = $CertPath
            Credential = $DomainCred
            DependsOn = '[xRemoteFile]DLCert'
        }


        xExchExchangeCertificate ExchCert
        {
            Credential = $DomainCred
            Ensure = 'Present'
            Thumbprint = $CertThumbprint            
            CertCreds = $CertCred
            CertFilePath = $CertPath
            DependsOn = '[xExchClientAccessServer]CAS','[xPfxImport]ExchCert'
            Services = 'IIS','SMTP'
        }        
       
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
    }
}
